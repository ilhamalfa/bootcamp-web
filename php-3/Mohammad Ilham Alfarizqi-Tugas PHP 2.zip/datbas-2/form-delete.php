<?php
    include "config.php";

    $id = $_GET['id_mhs'];

    $delete = mysqli_query($db, "DELETE FROM mahasiswa WHERE id_mahasiswa = '$id'");

    if($delete){
        header('Location: select-from.php');
    }else{
        echo "GAGAL";
    }
?>