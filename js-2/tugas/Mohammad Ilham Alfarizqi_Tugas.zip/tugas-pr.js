let numbers1 = [3,5,6,8,9];
let numbers2 = [1,3,5,7]

let middle1 = numbers1[Math.round((numbers1.length - 1) / 2)];
let middle2 = numbers2[Math.floor((numbers2.length) / 2)];

console.log("Median Dari Numbers1 = "+ middle1);
console.log("Median Dari Numbers2 = "+ middle2);

// node .\pertemuan-5\tugas\tugas-pr.js