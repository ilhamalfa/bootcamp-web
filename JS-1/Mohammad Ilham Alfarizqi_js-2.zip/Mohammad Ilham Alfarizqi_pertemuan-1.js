// luas Persegi
let sisi = 5;
let luas_persegi;

luas_persegi = sisi*sisi;

console.log("Luas Persegi = "+ luas_persegi);

// Luas Persegi Panjang
let panjang = 8;
let lebar = 6;
let luas_persegi_panjang;

luas_persegi_panjang = panjang * lebar;

console.log("Luas Persegi Panjang = "+ luas_persegi_panjang);

// Luas Lingkaran
let phi = 3.14;
let jari = 10;
let luas_lingkaran;

luas_lingkaran = phi * (jari * jari);

console.log("Luas Lingkaran = "+ luas_lingkaran);